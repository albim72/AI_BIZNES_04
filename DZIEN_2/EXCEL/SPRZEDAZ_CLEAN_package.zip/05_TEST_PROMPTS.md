# SPRZEDAZ_CLEAN - Test Prompts

## Prompt 1
Pracujesz wyłącznie na pliku Excel `01_Sprzedaz_czyszczenie_i_marza.xlsx`, arkusz `Transakcje`. Wykonaj analizę deterministycznie i bez domysłów.

## Prompt 2
Zastosuj deduplikację po Order_ID i SKU, zostaw najnowszy Loaded_At, usuń Cancelled, zwroty ustaw jako Qty ujemne i policz KPI.

## Prompt 3
Zwróć wynik dokładnie w 3 sekcjach: KPI, Top_10_SKU_By_Gross_Margin i Anomalies. Bez rekomendacji.

## Prompt 4
Jeżeli nie da się czegoś policzyć, wpisz NA i wyjaśnij tylko w QA_NOTES.

## Prompt 5
Pracuj tylko na arkuszu wskazanym w poleceniu. Nie używaj innych arkuszy i niczego nie zgaduj.

## Prompt 6
Nie dopisuj rekomendacji. Nie interpretuj danych biznesowo. Zwróć tylko wynik.
