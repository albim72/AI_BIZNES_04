# SPRZEDAZ_CLEAN - Data Cleaning Rules

## Kolejność przetwarzania
1. Sprawdź istnienie wskazanego arkusza.
2. Sprawdź obecność wymaganych kolumn.
3. Zidentyfikuj duplikaty po kluczu Order_ID + SKU.
4. W każdej grupie duplikatów pozostaw rekord z najnowszym Loaded_At.
5. Usuń rekordy, dla których Status = Cancelled.
6. Jeśli Return_Flag = Y, ustaw Qty jako wartość ujemną.
7. Oblicz Revenue_Net.
8. Oblicz COGS_Total.
9. Oblicz Gross_Margin.
10. Oblicz Gross_Margin_Pct tylko wtedy, gdy Revenue_Net != 0.
11. Oznacz anomalie.

## Wzory
Revenue_Net = Qty * Unit_Price * (1 - Discount_Pct)
COGS_Total = Qty * COGS_Unit
Gross_Margin = Revenue_Net - COGS_Total
Gross_Margin_Pct = Gross_Margin / Revenue_Net

## Reguły anomalii
- Discount_Pct > 0.20
- Gross_Margin < 0
- Jeśli oba warunki są spełnione, zwróć oba powody rozdzielone średnikiem
