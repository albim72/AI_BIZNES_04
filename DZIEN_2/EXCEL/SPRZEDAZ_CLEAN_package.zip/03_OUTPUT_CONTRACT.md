# SPRZEDAZ_CLEAN - Output Contract

## Zasada nadrzędna
Model ma zwracać odpowiedzi w ściśle określonym formacie i bez dodatkowych komentarzy, jeśli użytkownik tego nie zażąda.

## Dozwolone sekcje
- SEKCJA A
- SEKCJA B
- SEKCJA C
- QA_NOTES (tylko wtedy, gdy naprawdę jest potrzebne)

## Domyślny kontrakt odpowiedzi
### SEKCJA A
Tabela KPI z kolumnami:
- Metric
- Value

### SEKCJA B
Tabela Top_10_SKU_By_Gross_Margin z kolumnami:
- SKU
- Category
- Revenue_Net
- Gross_Margin
- Gross_Margin_Pct

### SEKCJA C
Tabela Anomalies z kolumnami:
- Order_ID
- SKU
- Discount_Pct
- Revenue_Net
- Gross_Margin
- Anomaly_Reason

## Reguły formatowania
- Używaj tabel markdown
- Nie dodawaj rekomendacji
- Nie dodawaj podsumowania
- Nie zmieniaj nazw sekcji
- Używaj NA tylko wtedy, gdy nie da się czegoś policzyć
- Wyjaśnienia dotyczące NA umieszczaj wyłącznie w QA_NOTES
