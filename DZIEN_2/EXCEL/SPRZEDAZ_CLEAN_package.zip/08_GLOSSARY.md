# SPRZEDAZ_CLEAN - Glossary

- Revenue_Net: przychód netto po uwzględnieniu rabatu
- COGS_Total: całkowity koszt sprzedanych towarów dla danej ilości
- Gross_Margin: marża brutto liczona jako Revenue_Net minus COGS_Total
- Gross_Margin_Pct: udział marży brutto w przychodzie netto, liczony tylko gdy Revenue_Net != 0
- Anomaly: rekord spełniający przynajmniej jeden warunek anomalii
- Duplicate: rekord mający ten sam Order_ID i SKU co inny rekord
- Latest row: rekord z najnowszym Loaded_At
- Cancelled: status rekordu przeznaczonego do usunięcia
- Return: zwrot skutkujący ujemnym Qty
