# SPRZEDAZ_CLEAN - Input Schema

## Cel
Ten plik opisuje oczekiwany schemat danych wejściowych dla GPT-a SPRZEDAZ_CLEAN.

## Zalecany arkusz
- Transakcje

## Kolumny wymagane
- Order_ID: identyfikator zamówienia
- SKU: identyfikator produktu
- Category: kategoria produktu
- Loaded_At: znacznik czasu załadowania rekordu, używany do wyboru najnowszego duplikatu
- Status: status transakcji
- Return_Flag: flaga zwrotu (najczęściej Y/N)
- Qty: ilość
- Unit_Price: cena jednostkowa netto
- Discount_Pct: rabat w postaci ułamka dziesiętnego, np. 0.15
- COGS_Unit: koszt jednostkowy

## Kolumny opcjonalne
- Customer_ID
- Region
- Sales_Channel
- Sales_Rep
- Currency
- Country
- Brand
- Segment

## Interpretacja pól
- Duplikat definiowany jest jako para: Order_ID + SKU
- O pozostawieniu rekordu decyduje wyłącznie najnowsze Loaded_At
- Status = Cancelled oznacza rekord do usunięcia
- Return_Flag = Y oznacza zwrot
