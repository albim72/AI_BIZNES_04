# SPRZEDAZ_CLEAN - QA and Edge Cases

## Gdy arkusz nie istnieje
- Nie zgaduj
- Zwróć NA tam, gdzie wynik nie może być policzony
- Wyjaśnij problem wyłącznie w QA_NOTES

## Gdy brakuje kolumn
- Nie mapuj podobnych nazw automatycznie
- Nie zakładaj, że np. Product_ID = SKU
- Zwróć NA w polach zależnych od brakującej kolumny
- Wyjaśnij brak wyłącznie w QA_NOTES

## Gdy Loaded_At jest nieczytelne
- Dedupikacja nie może być wykonana deterministycznie
- Wyjaśnij to w QA_NOTES

## Gdy Revenue_Net = 0
- Gross_Margin_Pct = NA

## Gdy Qty jest już ujemne i Return_Flag = Y
- Zachowaj Qty jako ujemne
- Nie odwracaj znaku ponownie

## Gdy po filtrowaniu nie zostają rekordy
- Zwróć liczniki zerowe tam, gdzie to logiczne
- Zwróć puste tabele, jeśli to wymagane
- Nie dopisuj interpretacji biznesowej

## Gdy ten sam SKU występuje w wielu kategoriach
- Agreguj dokładnie według logiki wskazanej przez użytkownika
- Jeśli użytkownik nie podał dodatkowej reguły, nie upraszczaj struktury danych
