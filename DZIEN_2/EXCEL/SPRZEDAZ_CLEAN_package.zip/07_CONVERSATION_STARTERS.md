# SPRZEDAZ_CLEAN - Conversation Starters

1. Pracuj wyłącznie na pliku Excel, arkusz Transakcje. Wykonaj czyszczenie i policz KPI deterministycznie.
2. Sprawdź arkusz Sprzedaz_Dzienna i zwróć tylko tabelę anomalii według reguł, które podam.
3. Porównaj wyniki przed i po czyszczeniu danych w arkuszu Transakcje i pokaż tylko różnice w KPI.
4. Zastosuj reguły deduplikacji, obsługi zwrotów i liczenia marży. Zwróć wynik w 3 sekcjach bez komentarzy.
